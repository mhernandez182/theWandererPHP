<?php

session_start();
initSession();
$_SESSION["userId"] = '1';
    if ($_SESSION["userId"] == ''){
        $uri = $_SERVER["REQUEST_URI"];
        if (strpos($uri, "index.php") === false){
           header('Location: index.php');
           $_SESSION["error"] = "Please select a user before proceeding.";
           

        }
    }

function initSession(){
            
            if(!isset($_SESSION['userId'])){
                $_SESSION['userId'] = '';
            }
            $_SESSION['fName'] = '';
            $_SESSION['lName'] = '';
            $_SESSION['bDate'] = '';
            $_SESSION['licenseExpiration'] = '';
            
            if(!isset($_SESSION['vehicleId'])){
                $_SESSION['vehicleId'] = '';
            }
            $_SESSION['year'] = '';
            $_SESSION['manufacturer'] = '';
            $_SESSION['model'] = '';
            
            if(!isset($_SESSION['shopId'])){
                $_SESSION['shopId'] = '';
            }
            $_SESSION['shopName'] = '';
            $_SESSION['shopAddress'] = '';
            $_SESSION['shopPhoneNo'] = '';
            $_SESSION['shopWebsite'] = '';
            $_SESSION['contactName'] = '';
            return;
}

function LogMsg($src,$msg){ // Write to log file to assist in debugging
    
                $myfile2 = fopen("h:\\autoMaintenance_log.txt", "a");
                $tm = time(0);
                fwrite($myfile2, "\r\n\r\n".$tm." - ".$src."\r\n    ".$msg);
                fclose($myfile2);
                return;
          }

function openDB(){
            $user = 'root';
            $pass = '';
            
            $db = new PDO("mysql:host=localhost;dbname=automaintenance", 
                    $user, $pass); 

            if ( $db != true){
                die("Unable to open DB");
            }
            return($db);

}

function createTables(){
    $db = openDB();
    
    $sql ="DROP TABLE IF EXISTS shops, tasks, vehicles, users ";
      $result = $db->query($sql);
            if ( $result != true){
                die("Unable to create tables.");
            }
            else{
                ECHO "<br>Tables Dropped and Recreated.<br>";
                
       }
       
$sql = "CREATE TABLE shops ( "
        ."id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY ,"
        ."userId INT(6) , "
        ."shopName VARCHAR(75)  NOT NULL ,"
        ."shopAddress VARCHAR(225) NOT NULL ,"
        ."shopPhoneNo  VARCHAR(20) ,"
        ."shopWebsite VARCHAR(150) ,"
        ."contactName  VARCHAR(100) ) ;";
    
     $result = $db->query($sql);
    if ($result != true){
        die( "<br>Unable to create shops table.");
    }
            
       
 $sql = "CREATE TABLE vehicles ( "
        ."id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,"
        ."userId INT(6), "         
        ."year VARCHAR(4) NOT NULL,"
        ."manufacturer VARCHAR(50) NOT NULL," 
        ."model VARCHAR(50) NOT NULL ) ;";
    
     $result = $db->query($sql);
    if ($result != true){
        die( "<br>Unable to create vehicles table.");
    }
       
       
    $sql = "CREATE TABLE users ( "
        ."id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY ,"
        ."fName VARCHAR(50) NOT NULL ,"
        ."lName VARCHAR(75) NOT NULL ,"
        ."bDate DATE ,"
        ."licenseExpiration DATE NOT NULL ) ;";
    
     $result = $db->query($sql);
    if ($result != true){
        die( "<br>Unable to create users table.");
    }

    
    $sql = "CREATE TABLE tasks( "
        ."id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,"
        ."userId INT(6), "
        ."vehicleId INT(6), "
        ."shopId INT(6), "     
        ."scheduleDate DATE NOT NULL ,"
        ."completeDate DATE NOT NULL ,"
        ."scheduleMileage VARCHAR(10) ,"
        ."serviceReason VARCHAR(255) NOT NULL ) ;";
    
    $result = $db->query($sql);
    if ($result != true){
        die("<br>Unable to create tasks table.");
    }
    
}

function newUser(){
if ( isset($_POST["newUser"])){
        $db = openDB();
            $sql ="INSERT INTO `users` ( `lName`, `fName`,`bDate`,`licenseExpiration` )"
                      ." VALUES " 
                    ."( '"
                    .$_POST['lName']."','"
                    .$_POST['fName']."','"
                    .$_POST['bDate']."','"
                    .$_POST['licenseExpiration']."' );"; 
            $result = $db->query($sql);
            if ( $result != true){
               LogMsg("index.php new user", $sql);
            }
            else{
                ECHO "<br/>User Saved.<br/>";
            }

    }
    
     if ( isset($_POST["updateUser"])){
        $db = openDB();
  
            $sql ="UPDATE `users`"
                    . " SET `lName` = '".$_POST['lName']."',"
                    . "`fName` =  '".$_POST['fName']."',"
                    . "`bDate` = '".$_POST['bDate']."',"
                    . "`licenseExpiration` = '".$_POST['licenseExpiration']."' "
                    . "WHERE id = ". $_SESSION["userId"];               
    
            $result = $db->query($sql);
            if ( $result != true){
               LogMsg("index.php update users", $sql);
            }
            else{
                ECHO "<br/>User updated.<br/>";
            }


    }
    
    if ( isset($_POST["deleteUser"])){
        $db = openDB();
            $sql ="DELETE FROM `users` WHERE id = ".$_SESSION["userId"]; 
            $result = $db->query($sql);
            if ( $result != true){             
               LogMsg("index.php delete users", $sql);
            }
            else{
                ECHO "<br/>User deleted.<br/>";
            }

    } 
}

function newVehicle(){
if ( isset($_POST["newVehicle"])){
        $db = openDB();
            $sql ="INSERT INTO `vehicles` (`userId`,`year`,`manufacturer`,`model`)"
                      ." VALUES " 
                    ."( '"
                    .$_SESSION['userId']."','"
                    .$_POST['year']."','"
                    .$_POST['manufacturer']."','"
                    .$_POST['model']."' );"; 
            $result = $db->query($sql);
            if ( $result != true){
               LogMsg("vehicles.php new vehicle", $sql);
            }
            else{
                ECHO "<br/>Vehicle saved.<br/>";
            }

    }
    
     if ( isset($_POST["updateVehicle"])){
        $db = openDB();
  
            $sql ="UPDATE `vehicles`"
                    . " SET `year` = '".$_POST['year']."',"
                    . "`manufacturer` =  '".$_POST['manufacturer']."',"
                    . "`model` = '".$_POST['model']."' "
                    . "WHERE id = ". $_SESSION["vehicleId"];               
    
            $result = $db->query($sql);
            if ( $result != true){
               LogMsg("vehicles.php update vehicles", $sql);
            }
            else{
                ECHO "<br/>Vehicle updated.<br/>";
            }


    }
    
    if ( isset($_POST["deleteVehicle"])){
        $db = openDB();
            $sql ="DELETE FROM `vehicles` WHERE id = ".$_SESSION["vehicleId"]; 
            $result = $db->query($sql);
            if ( $result != true){             
               LogMsg("vehicles.php delete vehicles", $sql);
            }
            else{
                ECHO "<br/>Vehicle deleted.<br/>";
            }

    } 
}

function newShop(){
if ( isset($_POST["newShop"])){
        $db = openDB();
            $sql ="INSERT INTO `shops` (`userId`,`shopName`,`shopAddress`,`shopPhoneNo`, `shopWebsite`, `contactName`)"
                      ." VALUES " 
                    ."( '"
                    .$_SESSION['userId']."','"
                    .$_POST['shopName']."','"
                    .$_POST['shopAddress']."','"
                    .$_POST['shopPhoneNo']."','"
                    .$_POST['shopWebsite']."','"
                    .$_POST['contactName']."' );"; 
            $result = $db->query($sql);
            if ( $result != true){
               LogMsg("shops.php new shop", $sql);
            }
            else{
                ECHO "<br/>Shop saved.<br/>";
            }

    }
    
     if ( isset($_POST["updateShop"])){
        $db = openDB();
  
            $sql ="UPDATE `shops`"
                    . " SET `shopName` = '".$_POST['shopName']."',"
                    . "`shopAddress` =  '".$_POST['shopAddress']."',"
                    . "`shopPhoneNo` =  '".$_POST['shopPhoneNo']."',"
                    . "`shopWebsite` =  '".$_POST['shopWebsite']."',"
                    . "`contactName` = '".$_POST['contactName']."' "
                    . "WHERE id = ". $_SESSION["shopId"];               
    
            $result = $db->query($sql);
            if ( $result != true){
               LogMsg("shops.php update shops", $sql);
            }
            else{
                ECHO "<br/>Shop updated.<br/>";
            }


    }
    
    if ( isset($_POST["deleteShop"])){
        $db = openDB();
            $sql ="DELETE FROM `shops` WHERE id = ".$_SESSION["shopId"]; 
            $result = $db->query($sql);
            if ( $result != true){             
               LogMsg("shops.php delete shops", $sql);
            }
            else{
                ECHO "<br/>Shops deleted.<br/>";
            }

    } 
}



function inputField($label,$type,$fldNm){

     if ( strtolower($type) == "text"
     ||  strtolower($type) == "date" ){
        echo '<br> <label for="',$fldNm,'">',$label,' </label>';
        echo '<br><input type="',$type,'" id = "',$fldNm,'" name = "',$fldNm ;
        echo '"value = "',$_SESSION[$fldNm],'">';
        return;
    }
}

function displayUsers(){
   
    $db = openDB();               
    $query = "SELECT id,lName,fName,bDate,licenseExpiration FROM users order by lName, fName;" ;
    $ds = $db->query($query);
    $cnt = $ds->rowCount();
    if ($cnt == 0){
        echo "<span> No users found.</span>";
        return; // No users 
    } 
    
    foreach ($ds as $row){
        echo "\n",'<div class= "scrollAreaLn">';
        echo '<span><a href="index.php?userId=',$row["id"],'">',$row['lName'],'</a> </span>';
        echo '<span>',$row['fName'],' </span>'; 
        echo "<span>",$row['bDate'],' </span>';
        echo '<span>',$row['licenseExpiration'],' </span>';    
        echo "\n</div>\n";

    }
    
}

function displayVehicles(){
   
    $db = openDB();               
    $query = "SELECT * FROM vehicles WHERE userId = ".$_SESSION['userId']." ORDER BY year, manufacturer;" ;
    $ds = $db->query($query);
    $cnt = $ds->rowCount();
    if ($cnt == 0){
        echo "<span> No vehicles found.</span>";
        return; // No users 
    } 
    
    foreach ($ds as $row){
        echo "\n",'<div class= "scrollAreaLn">';
        echo '<span><a href="vehicles.php?vehicleId=',$row["id"],'">',$row['year'],'</a> </span>';
        echo '<span>',$row['manufacturer'],' </span>'; 
        echo "<span>",$row['model'],' </span>'; 
        echo "\n</div>\n";

    }
    
}

function displayShops(){
   
    $db = openDB();               
    $query = "SELECT * FROM shops WHERE userId = ".$_SESSION['userId']." ORDER BY shopName;" ;
    $ds = $db->query($query);
    $cnt = $ds->rowCount();
    if ($cnt == 0){
        echo "<span> No shops found.</span>";
        return; // No users 
    } 
    
    foreach ($ds as $row){
        echo "\n",'<div class= "scrollAreaLn">';
        echo '<span><a href="shops.php?shopId=',$row["id"],'">',$row['shopName'],'</a> </span>';
        echo '<span>',$row['shopAddress'],' </span>'; 
        echo "<span>",$row['shopPhoneNo'],' </span>';
        echo "<span>",$row['shopWebsite'],' </span>';
        echo "<span>",$row['contactName'],' </span>';
        echo "\n</div>\n";

    }
    
}

function selectUser($userId){ // Retrieve user and set session variables
           
    $db = openDB();               
     $query = "Select id,lName,fName,bDate,licenseExpiration FROM users where id= "
     .$userId." ;";
    $ds = $db->query($query);
    $cnt = $ds->rowCount();
    if ($cnt == 0){
        die("<br> Could not find User ID".$query);
        return; // No users with this ID
    } 
    // Build list box of possible duplicates               

    foreach ($ds as $row){
        $_SESSION["userId"]=$row["id"];
        $_SESSION["lName"]=$row["lName"];
        $_SESSION["fName"]=$row["fName"];
        $_SESSION["bDate"]=$row["bDate"];
        $_SESSION["licenseExpiration"]=$row["licenseExpiration"];      
    }
 
}

function selectVehicle($vehicleId){ // Retrieve user and set session variables
           
    $db = openDB();               
     $query = "Select id,year,manufacturer,model FROM vehicles where id= "
     .$vehicleId." ;";
    $ds = $db->query($query);
    $cnt = $ds->rowCount();
    if ($cnt == 0){
        die("<br> Could not find Vehicle ID".$query);
        return; // No users with this ID
    } 
    // Build list box of possible duplicates               

    foreach ($ds as $row){
        $_SESSION["vehicleId"]=$row["id"];
        $_SESSION["year"]=$row["year"];
        $_SESSION["manufacturer"]=$row["manufacturer"];
        $_SESSION["model"]=$row["model"];   
    }
 
}

function selectShop($shopId){ // Retrieve user and set session variables
           
    $db = openDB();               
     $query = "Select id,shopName,shopAddress,shopPhoneNo,shopWebsite,contactName FROM shops where id= "
     .$shopId." ;";
    $ds = $db->query($query);
    $cnt = $ds->rowCount();
    if ($cnt == 0){
        die("<br> Could not find Shop ID".$query);
        return; // No users with this ID
    } 
    // Build list box of possible duplicates               

    foreach ($ds as $row){
        $_SESSION["shopId"]=$row["id"];
        $_SESSION["shopName"]=$row["shopName"];
        $_SESSION["shopAddress"]=$row["shopAddress"];
        $_SESSION["shopPhoneNo"]=$row["shopPhoneNo"];
        $_SESSION["shopWebsite"]=$row["shopWebsite"];
        $_SESSION["contactName"]=$row["contactName"];
    }
 
}

function userButtons(){

    if ($_SESSION["lName"] == ""){
       echo '<div class ="btn"> <input type="submit" name ="newUser" value="Save New User">  </div>';  
    }
    else
    {
       echo '<div class ="btn"> <input type="submit" name ="updateUser" value="Update User">  </div>';
       echo '<div class ="btn"> <input type="submit" name ="deleteUser" value="Delete User">  </div>';
    }
}

function vehicleButtons(){

    if ($_SESSION["model"] == ""){
       echo '<div class ="btn"> <input type="submit" name ="newVehicle" value="Save New Vehicle">  </div>';  
    }
    else
    {
       echo '<div class ="btn"> <input type="submit" name ="updateVehicle" value="Update Vehicle">  </div>';
       echo '<div class ="btn"> <input type="submit" name ="deleteVehicle" value="Delete Vehicle">  </div>';
    }
}

function shopButtons(){

    if ($_SESSION["shopName"] == ""){
       echo '<div class ="btn"> <input type="submit" name ="newShop" value="Save New Shop">  </div>';  
    }
    else
    {
       echo '<div class ="btn"> <input type="submit" name ="updateShop" value="Update Shop">  </div>';
       echo '<div class ="btn"> <input type="submit" name ="deleteShop" value="Delete Shop">  </div>';
    }
}


?>